import { useState, useEffect } from 'react';
import { onAuthStateChanged, User } from 'firebase/auth';
import { doc, getDoc } from 'firebase/firestore';
import { auth, db } from '../firebase/firebaseConfig';

interface AppUser extends User {
  role?: 'personnel' | 'admin';
}

export const useAuth = () => {
  const [user, setUser] = useState<AppUser | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (firebaseUser) => {
      if (firebaseUser) {
        // Fetch user role from Firestore
        const userDocRef = doc(db, 'users', firebaseUser.uid);
        const userDocSnap = await getDoc(userDocRef);

        if (userDocSnap.exists()) {
          const userData = userDocSnap.data();
          setUser({
            ...firebaseUser,
            role: userData.role as 'personnel' | 'admin',
          });
        } else {
          // CRITICAL: User exists in Auth but not Firestore document with role.
          // This state can cause routing loops if not handled.
          // Treat as unauthenticated for now to prevent issues.
          console.warn(`Firestore document not found for user: ${firebaseUser.uid}. Treating as unauthenticated.`);
          setUser(null); // Set user to null if role document is missing
        }
      } else {
        setUser(null);
      }
      setLoading(false); // Loading is false once auth state and role check are done
    });

    return () => unsubscribe();
  }, []);

  return { user, loading };
};
