import React, { useState, useEffect } from 'react';
import { auth, db } from '../firebase/firebaseConfig';
import { signOut } from 'firebase/auth';
import { collection, getDocs, addDoc, deleteDoc, doc, query, where, orderBy, serverTimestamp } from 'firebase/firestore'; // Added serverTimestamp
import { useAuth } from '../hooks/useAuth';
import { emailjs, serviceId, templateId, publicKey } from '../emailjs/emailjsConfig';

interface Personnel {
  id: string;
  email: string;
  role: 'personnel' | 'admin';
  // Add other user fields as needed (e.g., name, surname)
}

interface Factory {
  id: string;
  name: string;
}

interface Entry {
  id: string;
  userId: string;
  factoryId: string;
  type: 'entry' | 'exit';
  timestamp: any; // Firebase Timestamp
  location: { latitude: number; longitude: number };
  userName: string;
  factoryName: string;
}

function AdminDashboard() {
  const { user } = useAuth();
  const [personnelList, setPersonnelList] = useState<Personnel[]>([]);
  const [factories, setFactories] = useState<Factory[]>([]);
  const [entries, setEntries] = useState<Entry[]>([]);
  const [newPersonnelEmail, setNewPersonnelEmail] = useState('');
  const [newFactoryName, setNewFactoryName] = useState('');
  const [filterDate, setFilterDate] = useState('');
  const [filterPersonnel, setFilterPersonnel] = useState('');
  const [message, setMessage] = useState('');

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    // Fetch Personnel
    const personnelCollection = collection(db, 'users');
    const personnelSnapshot = await getDocs(query(personnelCollection, where('role', '==', 'personnel')));
    const personnelData = personnelSnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Personnel));
    setPersonnelList(personnelData);

    // Fetch Factories
    const factoriesCollection = collection(db, 'factories');
    const factorySnapshot = await getDocs(factoriesCollection);
    const factoryData = factorySnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Factory));
    setFactories(factoryData);

    // Fetch Entries (initial fetch, can be filtered later)
    const entriesCollection = collection(db, 'entries');
    const entriesSnapshot = await getDocs(query(entriesCollection, orderBy('timestamp', 'desc')));
    const entriesData = entriesSnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Entry));
    setEntries(entriesData);
  };

  const handleAddPersonnel = async (e: React.FormEvent) => {
    e.preventDefault();
    setMessage('');
    // Note: Adding user via Firebase Auth requires server-side (Cloud Functions)
    // This client-side code will only add a document to the 'users' collection
    // You would need a Cloud Function triggered by Auth user creation to set the role
    // Or use the Firebase Admin SDK server-side to create users with custom claims/roles.
    // For this demo, we'll just add the user to the 'users' collection with 'personnel' role.
    // The actual Auth user creation needs to be done separately (e.g., manually in Firebase console for demo).
    try {
      await addDoc(collection(db, 'users'), {
        email: newPersonnelEmail,
        role: 'personnel',
        createdAt: serverTimestamp()
        // Add other default fields if needed (e.g., name, surname)
      });
      setMessage('Personel başarıyla eklendi (Auth kullanıcısı ayrıca oluşturulmalıdır).');
      setNewPersonnelEmail('');
      fetchData(); // Refresh list
    } catch (error: any) {
      setMessage(`Personel eklenirken hata oluştu: ${error.message}`);
    }
  };

  const handleDeletePersonnel = async (personnelId: string) => {
    setMessage('');
     // Note: Deleting user via Firebase Auth requires server-side (Cloud Functions)
     // This client-side code will only delete the document from the 'users' collection
     // The actual Auth user deletion needs to be done separately (e.g., manually in Firebase console for demo).
    try {
      await deleteDoc(doc(db, 'users', personnelId));
      setMessage('Personel başarıyla silindi (Auth kullanıcısı ayrıca silinmelidir).');
      fetchData(); // Refresh list
    } catch (error: any) {
      setMessage(`Personel silinirken hata oluştu: ${error.message}`);
    }
  };

  const handleResetPassword = async (personnelEmail: string) => {
    setMessage('');
    // IMPORTANT: Resetting another user's password requires Firebase Admin SDK,
    // which runs server-side (e.g., in Cloud Functions or your own backend).
    // Client-side SDKs cannot do this for security reasons.
    // This function is a placeholder to show the UI element.
    // You would need to implement a Cloud Function that takes the user's UID
    // and uses admin.auth().updateUser(uid, { password: newPassword }) or
    // admin.auth().generatePasswordResetLink(email) to handle the reset.

    setMessage(`Personel (${personnelEmail}) için şifre sıfırlama talebi alındı. Bu işlem sunucu tarafında (Firebase Cloud Functions vb.) uygulanmalıdır.`);
    console.log(`Admin requested password reset for: ${personnelEmail}`);

    // Example of how you might call a Cloud Function (requires implementation):
    // try {
    //   const resetPasswordFunction = httpsCallable(functions, 'resetPersonnelPassword');
    //   await resetPasswordFunction({ email: personnelEmail });
    //   setMessage(`Şifre sıfırlama e-postası ${personnelEmail} adresine gönderildi.`);
    // } catch (error) {
    //   setMessage(`Şifre sıfırlama e-postası gönderilirken hata oluştu: ${error.message}`);
    // }
  };


  const handleAddFactory = async (e: React.FormEvent) => {
    e.preventDefault();
    setMessage('');
    try {
      await addDoc(collection(db, 'factories'), {
        name: newFactoryName,
        createdAt: serverTimestamp()
      });
      setMessage('Fabrika başarıyla eklendi.');
      setNewFactoryName('');
      fetchData(); // Refresh list
    } catch (error: any) {
      setMessage(`Fabrika eklenirken hata oluştu: ${error.message}`);
    }
  };

  const handleDeleteFactory = async (factoryId: string) => {
    setMessage('');
    try {
      await deleteDoc(doc(db, 'factories', factoryId));
      setMessage('Fabrika başarıyla silindi.');
      fetchData(); // Refresh list
    } catch (error: any) {
      setMessage(`Fabrika silinirken hata oluştu: ${error.message}`);
    }
  };

  const handleFilterEntries = async () => {
    setMessage('');
    let entriesQuery = collection(db, 'entries');

    // Basic filtering logic (can be expanded)
    if (filterDate) {
      // Filtering by date range requires more complex queries or server-side logic
      // For simplicity, this demo won't implement date filtering via Firestore client SDK
      // Firestore client SDK has limitations on range filters across multiple fields or complex date queries
      setMessage('Tarihe göre filtreleme şu an desteklenmiyor.');
      return;
    }

    if (filterPersonnel) {
       // Find the user ID for the given email
       const personnelQuery = query(collection(db, 'users'), where('email', '==', filterPersonnel));
       const personnelSnapshot = await getDocs(personnelQuery);
       if (!personnelSnapshot.empty) {
         const userId = personnelSnapshot.docs[0].id;
         entriesQuery = query(entriesQuery, where('userId', '==', userId));
       } else {
         setMessage('Belirtilen e-postaya sahip personel bulunamadı.');
         setEntries([]); // Clear entries if personnel not found
         return;
       }
    }

    try {
      const entriesSnapshot = await getDocs(query(entriesQuery, orderBy('timestamp', 'desc')));
      const entriesData = entriesSnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Entry));
      setEntries(entriesData);
      setMessage('Kayıtlar filtrelendi.');
    } catch (error: any) {
      setMessage(`Kayıtlar filtrelenirken hata oluştu: ${error.message}`);
    }
  };

  const handleSendDailyReport = async () => {
    setMessage('');
    if (!serviceId || !templateId || !publicKey) {
      setMessage('EmailJS yapılandırma bilgileri eksik.');
      return;
    }

    // Fetch entries for today (requires date filtering logic)
    // For demo, let's just send all currently filtered entries
    const reportData = entries.map(entry => ({
      timestamp: entry.timestamp?.toDate().toLocaleString() || 'N/A',
      userName: entry.userName,
      factoryName: entry.factoryName,
      type: entry.type === 'entry' ? 'Giriş' : 'Çıkış',
      location: `Lat: ${entry.location?.latitude.toFixed(4)}, Lng: ${entry.location?.longitude.toFixed(4)}`
    }));

    const emailContent = reportData.map(item =>
      `Zaman: ${item.timestamp}, Personel: ${item.userName}, Fabrika: ${item.factoryName}, Tip: ${item.type}, Konum: ${item.location}`
    ).join('\n');

    const templateParams = {
      to_email: 'serkan@2motomasyon.com.tr', // Admin email
      report_date: new Date().toLocaleDateString(),
      report_content: emailContent || 'Bugün için giriş/çıkış kaydı bulunamadı.',
    };

    try {
      await emailjs.send(serviceId, templateId, templateParams, publicKey);
      setMessage('Günlük rapor e-postası başarıyla gönderildi.');
    } catch (error: any) {
      setMessage(`Rapor gönderilirken hata oluştu: ${error.message}`);
      console.error('EmailJS error:', error);
    }
  };


  const handleLogout = async () => {
    try {
      await signOut(auth);
      // useAuth hook will handle redirection
    } catch (error: any) {
      console.error("Logout error:", error);
    }
  };

  return (
    <div className="container" style={{ maxWidth: '800px' }}>
      <h2>Admin Paneli</h2>
      {user && <p>Hoş geldiniz, {user.email}</p>}

      {message && <p style={{ marginTop: '15px', color: message.includes('hata') ? '#dc3545' : '#28a745' }}>{message}</p>}

      {/* Personnel Management */}
      <div style={{ marginTop: '30px', borderTop: '1px solid #eee', paddingTop: '20px' }}>
        <h3>Personel Yönetimi</h3>
        <form onSubmit={handleAddPersonnel} style={{ display: 'flex', gap: '10px', marginBottom: '20px' }}>
          <input
            type="email"
            placeholder="Yeni personel e-postası"
            value={newPersonnelEmail}
            onChange={(e) => setNewPersonnelEmail(e.target.value)}
            required
            style={{ flexGrow: 1 }}
          />
          <button type="submit">Ekle</button>
        </form>
        <h4>Mevcut Personel</h4>
        <ul style={{ listStyle: 'none', padding: 0 }}>
          {personnelList.map(personnel => (
            <li key={personnel.id} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '8px 0', borderBottom: '1px dotted #eee' }}>
              {personnel.email}
              <div>
                 <button onClick={() => handleResetPassword(personnel.email)} style={{ backgroundColor: '#ffc107', color: '#212529', padding: '5px 10px', fontSize: '0.8em', marginRight: '5px' }}>Şifre Sıfırla</button>
                 <button onClick={() => handleDeletePersonnel(personnel.id)} style={{ backgroundColor: '#dc3545', padding: '5px 10px', fontSize: '0.8em' }}>Sil</button>
              </div>
            </li>
          ))}
        </ul>
      </div>

      {/* Factory Management */}
      <div style={{ marginTop: '30px', borderTop: '1px solid #eee', paddingTop: '20px' }}>
        <h3>Fabrika Yönetimi</h3>
        <form onSubmit={handleAddFactory} style={{ display: 'flex', gap: '10px', marginBottom: '20px' }}>
          <input
            type="text"
            placeholder="Yeni fabrika adı"
            value={newFactoryName}
            onChange={(e) => setNewFactoryName(e.target.value)}
            required
            style={{ flexGrow: 1 }}
          />
          <button type="submit">Ekle</button>
        </form>
        <h4>Mevcut Fabrikalar</h4>
        <ul style={{ listStyle: 'none', padding: 0 }}>
          {factories.map(factory => (
            <li key={factory.id} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '8px 0', borderBottom: '1px dotted #eee' }}>
              {factory.name}
              <button onClick={() => handleDeleteFactory(factory.id)} style={{ backgroundColor: '#dc3545', padding: '5px 10px', fontSize: '0.8em' }}>Sil</button>
            </li>
          ))}
        </ul>
      </div>

      {/* Entry/Exit Reporting */}
      <div style={{ marginTop: '30px', borderTop: '1px solid #eee', paddingTop: '20px' }}>
        <h3>Giriş/Çıkış Raporları</h3>
        <div style={{ display: 'flex', gap: '10px', marginBottom: '20px', flexWrap: 'wrap' }}>
           {/* Date filtering is complex client-side with Firestore, omitting for demo */}
           {/* <input
             type="date"
             value={filterDate}
             onChange={(e) => setFilterDate(e.target.value)}
           /> */}
           <input
             type="text"
             placeholder="Personel E-posta ile filtrele"
             value={filterPersonnel}
             onChange={(e) => setFilterPersonnel(e.target.value)}
             style={{ flexGrow: 1 }}
           />
           <button onClick={handleFilterEntries}>Filtrele</button>
           <button onClick={fetchData} style={{ backgroundColor: '#6c757d' }}>Tümünü Göster</button>
        </div>

        <button onClick={handleSendDailyReport} style={{ marginBottom: '20px', backgroundColor: '#28a745' }}>Günlük Raporu E-posta Gönder</button>

        <h4>Kayıtlar</h4>
        <table style={{ width: '100%', borderCollapse: 'collapse', marginTop: '10px' }}>
          <thead>
            <tr style={{ backgroundColor: '#f2f2f2' }}>
              <th style={{ padding: '10px', border: '1px solid #ddd', textAlign: 'left' }}>Zaman</th>
              <th style={{ padding: '10px', border: '1px solid #ddd', textAlign: 'left' }}>Personel</th>
              <th style={{ padding: '10px', border: '1px solid #ddd', textAlign: 'left' }}>Fabrika</th>
              <th style={{ padding: '10px', border: '1px solid #ddd', textAlign: 'left' }}>Tip</th>
              <th style={{ padding: '10px', border: '1px solid #ddd', textAlign: 'left' }}>Konum</th>
            </tr>
          </thead>
          <tbody>
            {entries.length === 0 ? (
              <tr>
                <td colSpan={5} style={{ padding: '10px', border: '1px solid #ddd', textAlign: 'center' }}>Kayıt bulunamadı.</td>
              </tr>
            ) : (
              entries.map(entry => (
                <tr key={entry.id}>
                  <td style={{ padding: '10px', border: '1px solid #ddd' }}>{entry.timestamp?.toDate().toLocaleString()}</td>
                  <td style={{ padding: '10px', border: '1px solid #ddd' }}>{entry.userName}</td>
                  <td style={{ padding: '10px', border: '1px solid #ddd' }}>{entry.factoryName}</td>
                  <td style={{ padding: '10px', border: '1px solid #ddd' }}>{entry.type === 'entry' ? 'Giriş' : 'Çıkış'}</td>
                  <td style={{ padding: '10px', border: '1px solid #ddd' }}>
                    {entry.location ? `Lat: ${entry.location.latitude.toFixed(4)}, Lng: ${entry.location.longitude.toFixed(4)}` : 'N/A'}
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>


      <button onClick={handleLogout} style={{ marginTop: '30px', backgroundColor: '#dc3545' }}>Çıkış Yap</button>
    </div>
  );
}

export default AdminDashboard;
