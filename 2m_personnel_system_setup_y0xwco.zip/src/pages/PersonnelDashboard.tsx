import React, { useState, useEffect } from 'react'; // Added import
import { auth, db } from '../firebase/firebaseConfig';
import { signOut } from 'firebase/auth';
import { collection, getDocs, addDoc, serverTimestamp } from 'firebase/firestore';
import QRCode from 'qrcode.react';
import { useAuth } from '../hooks/useAuth';

interface Factory {
  id: string;
  name: string;
}

function PersonnelDashboard() {
  const { user } = useAuth();
  const [factories, setFactories] = useState<Factory[]>([]);
  const [selectedFactory, setSelectedFactory] = useState('');
  const [location, setLocation] = useState<{ latitude: number; longitude: number } | null>(null);
  const [locationError, setLocationError] = useState('');
  const [qrCodeValue, setQrCodeValue] = useState('');
  const [message, setMessage] = useState('');

  useEffect(() => {
    // Fetch factories
    const fetchFactories = async () => {
      const factoriesCollection = collection(db, 'factories');
      const factorySnapshot = await getDocs(factoriesCollection);
      const factoryList = factorySnapshot.docs.map(doc => ({
        id: doc.id,
        name: doc.data().name,
      }));
      setFactories(factoryList);
      if (factoryList.length > 0) {
        setSelectedFactory(factoryList[0].id);
      }
    };

    fetchFactories();

    // Get initial location
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          setLocation({
            latitude: position.coords.latitude,
            longitude: position.coords.longitude,
          });
          setLocationError('');
        },
        (error) => {
          setLocationError(`Konum alınamadı: ${error.message}`);
        }
      );
    } else {
      setLocationError('Tarayıcınız konum servislerini desteklemiyor.');
    }

  }, []);

  useEffect(() => {
    // Generate QR code value (e.g., user ID + timestamp + factory ID)
    if (user && selectedFactory) {
      const value = JSON.stringify({
        userId: user.uid,
        factoryId: selectedFactory,
        timestamp: Date.now(),
        type: 'entry' // Or 'exit', depending on the action
      });
      setQrCodeValue(value);
    }
  }, [user, selectedFactory]);


  const handleEntryExit = async (type: 'entry' | 'exit') => {
    if (!user || !selectedFactory || !location) {
      setMessage('Lütfen fabrika seçin ve konumun alınmasını bekleyin.');
      return;
    }

    try {
      await addDoc(collection(db, 'entries'), {
        userId: user.uid,
        factoryId: selectedFactory,
        type: type,
        timestamp: serverTimestamp(),
        location: location,
        userName: user.email, // Store user email for easier reporting
        factoryName: factories.find(f => f.id === selectedFactory)?.name // Store factory name
      });
      setMessage(`${type === 'entry' ? 'Giriş' : 'Çıkış'} kaydı başarıyla oluşturuldu.`);
    } catch (error: any) {
      setMessage(`Kayıt oluşturulurken hata oluştu: ${error.message}`);
    }
  };

  const handleLogout = async () => {
    try {
      await signOut(auth);
      // useAuth hook will handle redirection
    } catch (error: any) {
      console.error("Logout error:", error);
    }
  };

  return (
    <div className="container">
      <h2>Personel Paneli</h2>
      {user && <p>Hoş geldiniz, {user.email}</p>}

      <div className="form-group">
        <label htmlFor="factory">Fabrika Seçin:</label>
        <select
          id="factory"
          value={selectedFactory}
          onChange={(e) => setSelectedFactory(e.target.value)}
          disabled={factories.length === 0}
        >
          {factories.length === 0 ? (
            <option value="">Fabrikalar yükleniyor...</option>
          ) : (
            factories.map(factory => (
              <option key={factory.id} value={factory.id}>{factory.name}</option>
            ))
          )}
        </select>
      </div>

      <div className="form-group">
        <p>Konum Durumu: {location ? 'Alındı' : 'Alınıyor...'}</p>
        {locationError && <p className="error">{locationError}</p>}
        {location && <p>Lat: {location.latitude.toFixed(4)}, Lng: {location.longitude.toFixed(4)}</p>}
      </div>

      {qrCodeValue && (
        <div style={{ margin: '20px 0', textAlign: 'center' }}>
          <h3>Giriş/Çıkış QR Kodu</h3>
          <QRCode value={qrCodeValue} size={256} level="H" />
          <p style={{ fontSize: '0.8em', color: '#666' }}>Bu kodu fabrika giriş/çıkışında kullanın.</p>
           {/* In a real app, this QR would be scanned by a reader at the factory */}
           {/* For this demo, we'll use manual buttons */}
        </div>
      )}

      <div style={{ display: 'flex', justifyContent: 'space-around', marginTop: '20px' }}>
         <button onClick={() => handleEntryExit('entry')} disabled={!selectedFactory || !location}>
           Giriş Yap
         </button>
         <button onClick={() => handleEntryExit('exit')} disabled={!selectedFactory || !location}>
           Çıkış Yap
         </button>
      </div>


      {message && <p style={{ marginTop: '15px', color: message.includes('hata') ? '#dc3545' : '#28a745' }}>{message}</p>}


      <button onClick={handleLogout} style={{ marginTop: '20px', backgroundColor: '#dc3545' }}>Çıkış Yap</button>
    </div>
  );
}

export default PersonnelDashboard;
