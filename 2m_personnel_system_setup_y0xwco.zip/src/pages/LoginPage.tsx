import React, { useState } from 'react';
import { signInWithEmailAndPassword } from 'firebase/auth';
import { auth, db } from '../firebase/firebaseConfig'; // Import db for potential Firestore checks
import { useNavigate, Link } from 'react-router-dom';
import { emailjs, serviceId, templateId, publicKey } from '../emailjs/emailjsConfig';
import { doc, getDocs, collection, query, where } from 'firebase/firestore'; // Import Firestore functions

function LoginPage() {
  const [loginType, setLoginType] = useState<'personnel' | 'admin'>('personnel'); // State to toggle login type
  const [email, setEmail] = useState(''); // For admin login
  const [password, setPassword] = useState(''); // For both
  const [name, setName] = useState(''); // For personnel login
  const [surname, setSurname] = useState(''); // For personnel login
  const [error, setError] = useState('');
  const [message, setMessage] = useState('');
  const navigate = useNavigate();

  const handlePersonnelLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setMessage('');

    if (!name || !surname || !password) {
      setError('Lütfen Ad, Soyad ve Şifre alanlarını doldurun.');
      return;
    }

    try {
      // --- Personnel Login Logic (Requires Custom Implementation) ---
      // Firebase Auth does not support login with Name/Surname directly.
      // You need a custom backend or Firestore check here.
      // Example (Placeholder - NOT a secure or complete implementation):
      const personnelQuery = query(collection(db, 'users'),
        where('name', '==', name),
        where('surname', '==', surname),
        // WARNING: Comparing plain text passwords is INSECURE.
        // You MUST hash passwords and compare hashes in a secure backend.
        // This is a placeholder to show where the check would go.
        // where('password', '==', password) // DANGER: Do NOT do this in production
      );

      const querySnapshot = await getDocs(personnelQuery);

      if (!querySnapshot.empty) {
        // Found a user matching Name and Surname
        // Now, you would typically verify the password hash against the stored hash.
        // Since we cannot do secure password hashing/comparison client-side,
        // this part is incomplete and requires a backend.

        // For demonstration, let's assume the first match is the user
        const userData = querySnapshot.docs[0].data();
        const userId = querySnapshot.docs[0].id;

        // --- Placeholder for successful personnel login ---
        // In a real app, after verifying the password hash securely on a backend,
        // you would establish a session (e.g., store a token in local storage)
        // and update the auth state accordingly.
        console.log(`Personnel login successful (placeholder): User ID ${userId}, Role: ${userData.role}`);
        setMessage('Personel girişi başarılı (Doğrulama mantığı eksik).');
        // You would then redirect or update app state based on role
        // navigate('/personnel-dashboard'); // Example redirect
      } else {
        setError('Ad, Soyad veya Şifre hatalı.');
      }

    } catch (err: any) {
      setError(`Giriş sırasında hata oluştu: ${err.message}`);
      console.error('Personnel login error:', err);
    }
  };

  const handleAdminLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setMessage('');

    if (!email || !password) {
      setError('Lütfen E-posta ve Şifre alanlarını doldurun.');
      return;
    }

    try {
      // --- Admin Login Logic (Using Firebase Auth) ---
      await signInWithEmailAndPassword(auth, email, password);
      // useAuth hook will handle redirection after state updates
    } catch (err: any) {
      setError(err.message);
    }
  };

  const handleForgotPassword = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setMessage('');

    // This function is primarily for personnel who might forget their password.
    // Since personnel don't use email for login, this request goes to the admin.
    // The email field here is used to identify *which* personnel needs a reset.
    // It assumes personnel have an email associated with their account in Firestore.

    if (!email) {
      setMessage('Şifresini unuttuğunuz personelin e-postasını girin.');
      return;
    }

    if (!serviceId || !templateId || !publicKey) {
      setMessage('EmailJS yapılandırma bilgileri eksik. Lütfen .env dosyasını kontrol edin.');
      return;
    }

    // Optional: Verify if an personnel user with this email exists in Firestore
    try {
      const personnelQuery = query(collection(db, 'users'),
        where('email', '==', email),
        where('role', '==', 'personnel') // Ensure it's a personnel user
      );
      const querySnapshot = await getDocs(personnelQuery);

      if (querySnapshot.empty) {
        setMessage('Belirtilen e-posta adresine sahip bir personel bulunamadı.');
        return;
      }

      const userData = querySnapshot.docs[0].data();
      const personnelName = userData.name || 'Bilinmiyor';
      const personnelSurname = userData.surname || 'Bilinmiyor';


      const templateParams = {
        user_email: email, // Email of the personnel requesting reset
        user_name: personnelName,
        user_surname: personnelSurname,
        admin_email: 'serkan@2motomasyon.com.tr', // Target admin email
      };

      // Send email to admin notifying about password reset request
      await emailjs.send(serviceId, templateId, templateParams, publicKey);
      setMessage(`Şifre sıfırlama talebiniz yöneticiye (${templateParams.admin_email}) iletildi.`);
      setEmail(''); // Clear email field after request
      setName(''); // Clear name field
      setSurname(''); // Clear surname field
    } catch (error: any) {
      setMessage(`Şifre sıfırlama talebi gönderilirken hata oluştu: ${error.message}`);
      console.error('EmailJS error:', error);
    }
  };


  return (
    <div className="container">
      <h2>Giriş Yap</h2>

      <div style={{ marginBottom: '20px', textAlign: 'center' }}>
        <button
          onClick={() => setLoginType('personnel')}
          style={{
            marginRight: '10px',
            padding: '10px 20px',
            cursor: 'pointer',
            backgroundColor: loginType === 'personnel' ? '#007bff' : '#e9ecef',
            color: loginType === 'personnel' ? 'white' : '#495057',
            border: 'none',
            borderRadius: '5px'
          }}
        >
          Personel Girişi
        </button>
        <button
          onClick={() => setLoginType('admin')}
          style={{
            padding: '10px 20px',
            cursor: 'pointer',
            backgroundColor: loginType === 'admin' ? '#007bff' : '#e9ecef',
            color: loginType === 'admin' ? 'white' : '#495057',
            border: 'none',
            borderRadius: '5px'
          }}
        >
          Admin Girişi
        </button>
      </div>

      {loginType === 'personnel' && (
        <form onSubmit={handlePersonnelLogin}>
          <h3>Personel Girişi</h3>
          <div className="form-group">
            <label htmlFor="name">Ad:</label>
            <input
              type="text"
              id="name"
              value={name}
              onChange={(e) => setName(e.target.value)}
              required
            />
          </div>
          <div className="form-group">
            <label htmlFor="surname">Soyad:</label>
            <input
              type="text"
              id="surname"
              value={surname}
              onChange={(e) => setSurname(e.target.value)}
              required
            />
          </div>
          <div className="form-group">
            <label htmlFor="password">Şifre:</label>
            <input
              type="password"
              id="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
            />
          </div>
          {error && <p className="error">{error}</p>}
          {message && <p style={{ color: message.includes('hata') ? '#dc3545' : '#28a745' }}>{message}</p>}

          <button type="submit">Giriş</button>

          <div style={{ marginTop: '15px', textAlign: 'center' }}>
            <p>Şifrenizi mi unuttunuz?</p>
            {/* For personnel forgot password, we still need an identifier, using email here */}
            <div className="form-group">
              <label htmlFor="forgot-email">Personel E-postası:</label>
              <input
                type="email"
                id="forgot-email"
                value={email} // Reuse email state for forgot password email input
                onChange={(e) => setEmail(e.target.value)}
                placeholder="Şifresini unuttuğunuz personelin e-postası"
              />
            </div>
            <button onClick={handleForgotPassword} style={{ backgroundColor: '#ffc107', color: '#212529', border: 'none', padding: '8px 15px', cursor: 'pointer' }}>
              Şifremi Sıfırla Talebi Gönder
            </button>
          </div>
        </form>
      )}

      {loginType === 'admin' && (
        <form onSubmit={handleAdminLogin}>
          <h3>Admin Girişi</h3>
          <div className="form-group">
            <label htmlFor="admin-email">E-posta:</label>
            <input
              type="email"
              id="admin-email"
              value={email} // Reuse email state for admin email input
              onChange={(e) => setEmail(e.target.value)}
              required
            />
          </div>
          <div className="form-group">
            <label htmlFor="admin-password">Şifre:</label>
            <input
              type="password"
              id="admin-password"
              value={password} // Reuse password state for admin password input
              onChange={(e) => setPassword(e.target.value)}
              required
            />
          </div>
          {error && <p className="error">{error}</p>}
          {message && <p style={{ color: message.includes('hata') ? '#dc3545' : '#28a745' }}>{message}</p>}

          <button type="submit">Giriş</button>
           {/* Admin forgot password would typically use Firebase's sendPasswordResetEmail,
               but the user requested personnel forgot password sends email to admin.
               Keeping this simple for now. */}
        </form>
      )}

    </div>
  );
}

export default LoginPage;
