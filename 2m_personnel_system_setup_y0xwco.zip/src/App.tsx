import React from 'react'; // Added import
import { Routes, Route, Navigate } from 'react-router-dom';
import LoginPage from './pages/LoginPage';
import PersonnelDashboard from './pages/PersonnelDashboard';
import AdminDashboard from './pages/AdminDashboard';
import { useAuth } from './hooks/useAuth'; // We will create this hook

function App() {
  const { user, loading } = useAuth(); // Assume useAuth provides user and loading state

  if (loading) {
    return <div>Loading...</div>; // Simple loading indicator
  }

  return (
    <Routes>
      <Route path="/login" element={user ? <Navigate to={user.role === 'admin' ? "/admin" : "/personnel"} /> : <LoginPage />} />
      <Route path="/personnel" element={user && user.role === 'personnel' ? <PersonnelDashboard /> : <Navigate to="/login" />} />
      <Route path="/admin" element={user && user.role === 'admin' ? <AdminDashboard /> : <Navigate to="/login" />} />
      <Route path="*" element={<Navigate to="/login" />} /> {/* Redirect unknown paths to login */}
    </Routes>
  );
}

export default App;
